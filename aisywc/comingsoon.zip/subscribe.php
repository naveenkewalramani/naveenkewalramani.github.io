<?php

if(isset($_POST['email'])) {
 


    // EDIT THE 2 LINES BELOW AS REQUIRED
 
  
$file1=$_REQUEST["file1"];


  $email_to = "sunakshi22@gmail.com";
 
    $email_subject = "Subscribe aisywc.in";

   
    $email_from = $_POST['email']; // required
 
    $email_message = "Hye, I am interested in your newsletters!.\n\n";
 
    
    $email_message .= "Email: ".$email_from."\n";
 
    



 
$headers .='Reply-To:  <'.$email_from.'>' . "\r\n";
$headers .= 'From: AISYWC <'.$email_from.'>'."\r\n";
$headers .= 'MIME-Version: 1.0' . "\ r\n";
$headers .= ' Content-type: text/html; charset=iso-8859-1' . "\ r\n";

mail($email_to, $email_subject, $email_message, $headers);  
     
$redirect  = $_POST['redirect'];
header('Location: ' . $_SERVER['HTTP_REFERER']);

?>
 
 
<?php
 
}
 
?>