<?php
 
header('Location: index.html');


if(isset($_POST['email'])) {

    // EDIT THE 2 LINES BELOW AS REQUIRED
 
    $email_to = "sunakshi22@gmail.com";
    $email_from = $_POST['email'];
    $email_subject = "Message from aisywc.in";

    $message = $_POST['message']; // required
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $clg = $_POST['college'];
  $email_message = "Hye, I am interested in knowing something, please help!.\n\n";
  $email_message .= "Name: ".$name."\n";
  $email_message .= "Phone: ".$phone."\n";
  $email_message .= "College/Org: ".$clg."\n";
  $email_message .= "Message: ".$message."\n"; 
  $email_message .= "Email: ".$email_from."\n";
  

 
 
$headers .='Reply-To:  <'.$email_from.'>' . "\r\n";
$headers .= 'From: AISYWC <'.$email_from.'>'."\r\n";
$headers .= 'MIME-Version: 1.0' . "\ r\n";
$headers .= ' Content-type: text/html; charset=iso-8859-1' . "\ r\n";


// Additional headers

mail($email_to, $email_subject, $email_message, $headers);  
 
?>
 
 
<?php
 
}
 
?>